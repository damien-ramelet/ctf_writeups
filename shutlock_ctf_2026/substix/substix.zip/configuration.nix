# /etc/nixos/configuration.nix
# Production server - infra-api-01.internal.shutlock.fr
# Last modified: 2026-03-18
{
  config,
  pkgs,
  ...
}: {
  imports = [
    ./hardware-configuration.nix
  ];

  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;

  networking.hostName = "infra-api-01";
  networking.domain = "internal.shutlock.fr";

  time.timeZone = "Europe/Paris";

  # Nix settings
  nix = {
    settings = {
      experimental-features = ["nix-command" "flakes"];

      substituters = [
        "https://substix.shutlock.fr"
        "https://cache.nixos.org"
      ];

      trusted-public-keys = [
        "substix-nix-cache:ggiTJONsWRiQpkJOrP2Km/CI4omYwCssO6O4qbmZCdA="
        "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
      ];
    };

    gc = {
      automatic = true;
      dates = "weekly";
      options = "--delete-older-than 30d";
    };
  };

  # System packages
  environment.systemPackages = with pkgs; [
    vim
    git
    htop
    tmux
    curl
    jq
  ];

  # SSH
  services.openssh = {
    enable = true;
    settings = {
      PermitRootLogin = "no";
      PasswordAuthentication = false;
    };
  };

  # Firewall
  networking.firewall = {
    enable = true;
    allowedTCPPorts = [22 80 443 8080];
  };

  # Users
  users.users.deploy = {
    isNormalUser = true;
    extraGroups = ["wheel" "docker"];
    openssh.authorizedKeys.keys = [
      "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBzG3kFrPbKHx0qGz2FQhT4r3OajiNm0XCnRl9KMPSW3 deploy@ci"
    ];
  };

  system.stateVersion = "24.11";
}
