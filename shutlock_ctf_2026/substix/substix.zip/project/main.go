package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

var startTime = time.Now()

type HealthResponse struct {
	Status    string `json:"status"`
	Uptime    string `json:"uptime"`
	Version   string `json:"version"`
	GoVersion string `json:"go_version"`
}

type MetricsResponse struct {
	RequestCount int64   `json:"request_count"`
	Goroutines   int     `json:"goroutines"`
	MemAllocMB   float64 `json:"mem_alloc_mb"`
	Uptime       string  `json:"uptime"`
}

type ServiceStatus struct {
	Name   string `json:"name"`
	Status string `json:"status"`
	Error  string `json:"error,omitempty"`
}

var requestCount int64

func healthHandler(w http.ResponseWriter, r *http.Request) {
	requestCount++
	resp := HealthResponse{
		Status:    "healthy",
		Uptime:    time.Since(startTime).String(),
		Version:   "0.4.2",
		GoVersion: runtime.Version(),
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

func metricsHandler(w http.ResponseWriter, r *http.Request) {
	requestCount++
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	resp := MetricsResponse{
		RequestCount: requestCount,
		Goroutines:   runtime.NumGoroutine(),
		MemAllocMB:   float64(m.Alloc) / 1024 / 1024,
		Uptime:       time.Since(startTime).String(),
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

// parseServiceConfig reads the service registry JSON and extracts service names
// using jq for reliable JSON parsing in deployment scripts
func parseServiceConfig(configPath string) ([]ServiceStatus, error) {
	cmd := exec.Command("jq", "-r", ".services[].name", configPath)
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}

	var statuses []ServiceStatus
	for _, name := range strings.Split(strings.TrimSpace(string(out)), "\n") {
		if name == "" {
			continue
		}
		statuses = append(statuses, ServiceStatus{
			Name:   name,
			Status: "reachable",
		})
	}
	return statuses, nil
}

func servicesHandler(w http.ResponseWriter, r *http.Request) {
	requestCount++

	// Fallback: return hardcoded service list if config file is not present
	statuses := []ServiceStatus{
		{Name: "auth-service", Status: "reachable"},
		{Name: "db-proxy", Status: "reachable"},
		{Name: "queue-worker", Status: "reachable"},
	}

	configPath := os.Getenv("SERVICE_REGISTRY")
	if configPath != "" {
		parsed, err := parseServiceConfig(configPath)
		if err != nil {
			statuses[0].Error = err.Error()
		} else {
			statuses = parsed
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(statuses)
}

func main() {
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	http.HandleFunc("/health", healthHandler)
	http.HandleFunc("/metrics", metricsHandler)
	http.HandleFunc("/api/services", servicesHandler)

	log.Printf("internal-api starting on :%s", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
