{
  description = "Internal API service - infrastructure monitoring & health checks";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-24.11";
  };

  outputs = { self, nixpkgs }:
    let
      system = "x86_64-linux";
      pkgs = nixpkgs.legacyPackages.${system};
    in
    {
      devShells.${system}.default = pkgs.mkShell {
        buildInputs = with pkgs; [
          go
          gopls
          jq # Critical Debug
        ];

        shellHook = ''
          echo "internal-api dev environment loaded"
          echo "go version: $(go version)"
        '';
      };

      packages.${system}.default = pkgs.buildGoModule {
        pname = "internal-api";
        version = "0.4.2";
        src = ./.;
        vendorHash = null;

        nativeBuildInputs = with pkgs; [ makeWrapper ];

        postInstall = ''
          wrapProgram $out/bin/internal-api \
            --prefix PATH : ${pkgs.lib.makeBinPath [ pkgs.jq ]}
        '';

        meta = with pkgs.lib; {
          description = "Internal infrastructure API service";
          license = licenses.mit;
        };
      };
    };
}
