import os
import time
from playwright.sync_api import sync_playwright

TARGET = os.environ.get('APP_URL', 'http://app:5000')
AGENT_TOKEN = os.environ.get('AGENT_TOKEN', 'agenttoken123')
FLAG = os.environ.get('FLAG', 'CTF{super_secret_flag_test}')
INTERVAL = int(os.environ.get('INTERVAL_BOT', '40'))

POST_URL = f"{TARGET}/post"
LOGIN_URL = f"{TARGET}/"

def run_bot():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=[
        '--disable-extensions',
        '--disable-default-apps',
        '--disable-sync',
        '--disable-gpu',
        '--no-sandbox',
        '--disable-dev-shm-usage',])
        context = browser.new_context()
        page = context.new_page()

        print('[+] Bot started', flush=True)

        while True:
            try:
                page.goto(LOGIN_URL)
                print('[+] Bot on login page', flush=True)
                page.fill('input[name="q"]', AGENT_TOKEN)
                print('[+] Bot filled token', flush=True)
                page.click('button[type="submit"]')
                print('[+] Bot submitted token', flush=True)

                try:
                    page.wait_for_url('**/discussion', timeout=5000)
                    print('[+] Bot logged in successfully', flush=True)
                except Exception:
                    print('[-] Bot login failed', flush=True)
                    pass

                page.evaluate(
                    """({postUrl, flag}) =>
                        fetch(postUrl, {
                            method: 'POST',
                            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                            body: `content=${encodeURIComponent(flag)}`
                        })""",
                    {"postUrl": POST_URL, "flag": FLAG}
                )
                print('[+] Posted flag', flush=True)

                try:
                    page.goto(f"{TARGET}/discussion")
                    print('[+] Bot on /discussion', flush=True)
                except Exception:
                    print('[-] Bot failed to navigate to /discussion', flush=True)
                    pass

            except Exception as e:
                print('[-] Bot error', e, flush=True)
                
            time.sleep(INTERVAL)

if __name__ == '__main__':
    run_bot()