document.getElementById('postForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const form = e.target;
      const data = new URLSearchParams(new FormData(form));
      await fetch('/post', { method: 'POST', body: data });
      setTimeout(() => location.reload(), 100);
});