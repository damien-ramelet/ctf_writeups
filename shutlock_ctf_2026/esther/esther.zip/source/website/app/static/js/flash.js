document.addEventListener("DOMContentLoaded", () => {
  const flashes = document.querySelectorAll('.flash-message');
  flashes.forEach(flash => {
    setTimeout(() => {
      flash.style.transition = "opacity 0.5s ease";
      flash.style.opacity = "0";
    }, 2500);
    setTimeout(() => flash.remove(), 4000);
  });
});
