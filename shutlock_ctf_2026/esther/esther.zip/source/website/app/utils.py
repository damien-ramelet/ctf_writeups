from flask import session

def check_tech_auth(req):
    return session.get('role') == 'tech'

def check_agent_auth(req):
    return session.get('role') == 'agent'

def is_note_content_safe(content):
    if len(content) > 60:
        return False
    allowed_chars = set("abcdefghijklmnopqrstuvwxyz:-(){};")
    return all(c in allowed_chars for c in content)

def is_css_safe(css_text):
    if len(css_text) > 50:
        return False
    forbidden_substrings = [
        '[', ']', '*', '^', '<', '>', "'", '"', '-', 'val', 'attr', ':', 'if', 'else',
        'javascript:', '{', '}', 'div', 'body', 'html', 'form', 'script', 'img',
        'expression', 'onerror', 'onload', 'set', 'background', 'http'
    ]
    for fs in forbidden_substrings:
        if fs in css_text.lower():
            return False
    return True
