from flask import Blueprint, render_template, jsonify, request, abort, url_for, flash, redirect
from ..models import RequestLog, Note, CSSStore, RandomValue
from .. import db
from ..utils import check_tech_auth, is_css_safe

tech_bp = Blueprint('tech', __name__)

@tech_bp.route('/tech')
def tech_panel():
    if not check_tech_auth(request):
        return abort(403)
    
    logs = RequestLog.query.order_by(RequestLog.timestamp.desc()).limit(500).all()
    notes = Note.query.order_by(Note.created_at.desc()).limit(100).all()
    css = CSSStore.query.first()

    return render_template('technician.html', logs=logs, notes=notes, css=(css.css if css else ''))

@tech_bp.route('/tech/set_css', methods=['POST'])
def tech_set_css():
    if not check_tech_auth(request):
        return abort(403)
    
    css_text = request.form.get('css', '')
    if not is_css_safe(css_text):
        flash('CSS not safe', 'error')
        return redirect(url_for('tech.tech_panel'))
    
    css = CSSStore.query.first()
    if not css:
        css = CSSStore(css=css_text)
        db.session.add(css)
    else:
        css.css = css_text
    db.session.commit()

    flash('CSS updated', 'success')
    return redirect(url_for('tech.tech_panel'))

@tech_bp.route('/tech/recovery')
def tech_recovery():
    recovery = RandomValue.query.filter_by(key='tech_pass').first()
    if not recovery:
        return jsonify({'error':'no recovery value set'}), 404
    
    return jsonify({'recovery_value': recovery.value})