import random
from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, session, redirect, url_for, jsonify, abort
from ..models import Message, RandomValue, CSSStore
from .. import db
from ..config import FAKE_CDS, AGENT_TOKEN, EXPIRE_SECONDS_MSG
from ..utils import check_agent_auth

main_bp = Blueprint('main', __name__)

@main_bp.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        q = request.form.get('q','').strip()
        
        if q and q == AGENT_TOKEN:
            session.clear()
            session['role'] = 'agent'
            session['author'] = 'bot'
            return redirect(url_for('main.discussion'))
        
        tech = RandomValue.query.filter_by(key='tech_pass').first()
        if q and tech and q == tech.value:
            session.clear()
            session['role'] = 'tech'
            return redirect(url_for('tech.tech_panel'))
        
        results = [c for c in FAKE_CDS if q.lower() in c['title'].lower() or q.lower() in c['artist'].lower()]
        return render_template('index.html', results=results, q=q)
    
    return render_template('index.html', results=random.sample(FAKE_CDS, 25), q='')

@main_bp.route('/discussion')
def discussion():
    if not check_agent_auth(session):
        return abort(403)
    
    css = CSSStore.query.first()
    now = datetime.utcnow()

    try:
        Message.query.filter(Message.expires_at <= now).delete()
        db.session.commit()
    except Exception:
        db.session.rollback()
    
    messages = Message.query.order_by(Message.created_at.desc()).all()
    return render_template('discussion.html', messages=messages, css=(css.css if css else ''))

@main_bp.route('/post', methods=['POST'])
def post_message():
    if not check_agent_auth(session):
        return jsonify({'error': 'forbidden'}), 403
    
    author = session.get('author', 'agent')
    content = request.form.get('content')
    
    if not content:
        return jsonify({'error': 'missing content'}), 400
    
    now = datetime.utcnow()
    expires = now + timedelta(seconds=EXPIRE_SECONDS_MSG)
    msg = Message(author=author, content=content, created_at=now, expires_at=expires)
    
    db.session.add(msg)
    db.session.commit()

    return jsonify({'status': 'ok'})