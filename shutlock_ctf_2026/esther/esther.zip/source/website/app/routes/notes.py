import uuid
from flask import Blueprint, request, redirect, render_template, abort, url_for, session, flash
from ..models import Note
from .. import db
from ..utils import check_tech_auth, check_agent_auth, is_note_content_safe

notes_bp = Blueprint('notes', __name__)

@notes_bp.route('/tech/add_note', methods=['POST'])
def tech_add_note():
    if not check_tech_auth(session):
        return abort(403)
    
    content = request.form.get('content')
    if not content:
        flash('Missing content', 'error')
        return redirect(url_for('tech.tech_panel'))
   
    if not is_note_content_safe(content):
        flash('Unsafe content', 'error')
        return redirect(url_for('tech.tech_panel'))

    slug = uuid.uuid4().hex[:16]
    note = Note(slug=slug, content=content)
    db.session.add(note)
    db.session.commit()

    flash('Note added', 'success')
    return redirect(url_for('tech.tech_panel'))

@notes_bp.route('/notes/<slug>')
def view_note(slug):
    if not (check_tech_auth(session) or check_agent_auth(session)):
        return abort(403)
    
    n = Note.query.filter_by(slug=slug).first_or_404()
    
    fmt = request.args.get('fmt', '')
    banned_formats = ['css', 'csv', 'html', 'calendar', 'javascript', 'js', 'json', 'xml', 'xhtml', 'svg', 'webmanifest', 'wasm']
    if fmt.isalpha() and len(fmt) > 1 and fmt not in banned_formats:
        return n.content, 200, {'Content-Type': f'text/{fmt}; charset=utf-8'}
    
    return render_template('note.html', note=n)
