import secrets
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app():
    from .config import DB_PATH, CSP, RECOVERY_ENDPOINT, AGENT_TOKEN
    from .models import RandomValue
    from .routes.main import main_bp
    from .routes.tech import tech_bp
    from .routes.notes import notes_bp

    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = DB_PATH
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.secret_key = secrets.token_urlsafe(64)
    db.init_app(app)

    with app.app_context():
        db.create_all()
        # create technician password
        if not RandomValue.query.filter_by(key='tech_pass').first():
            tech_pass = secrets.token_urlsafe(16)
            rv = RandomValue(key='tech_pass', value=tech_pass)
            db.session.add(rv)
            db.session.commit()
            print('Technician password generated:', tech_pass, flush=True)
        else:
            print('Technician password already present', flush=True)
        print('Agent token is:', AGENT_TOKEN, flush=True)

    from .models import RequestLog
    @app.before_request
    def log_request():
        try:
            rl = RequestLog(
                path=request.path + ("?" + request.query_string.decode() if request.query_string else ""),
                method=request.method
            )
            db.session.add(rl)
            db.session.commit()
        except Exception:
            db.session.rollback()

    @app.before_request
    def block_recovery_endpoint():
        raw_path = request.environ.get("RAW_URI", request.environ.get("REQUEST_URI"))
        if raw_path == RECOVERY_ENDPOINT:
            return jsonify({"error": "forbidden"}), 403

    @app.after_request
    def add_csp_headers(response):
        response.headers['Content-Security-Policy'] = "; ".join([f"{k} {v}" for k, v in CSP.items()])
        return response

    app.register_blueprint(main_bp)
    app.register_blueprint(tech_bp)
    app.register_blueprint(notes_bp)

    return app