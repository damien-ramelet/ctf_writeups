FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt
COPY website ./
CMD ["gunicorn", "-w", "1", "-b", "0.0.0.0:5000", "run:app", "--capture-output", "--log-level", "info"]
